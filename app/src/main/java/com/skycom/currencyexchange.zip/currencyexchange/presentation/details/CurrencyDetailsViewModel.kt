package com.skycom.currencyexchange.presentation.details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skycom.currencyexchange.domain.repository.CurrencyRepository
import com.skycom.currencyexchange.presentation.common.formatRate
import com.skycom.currencyexchange.presentation.common.toDisplayName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.abs

@HiltViewModel
class CurrencyDetailsViewModel @Inject constructor(
    private val repository: CurrencyRepository,
    private val clock: java.time.Clock,
) : ViewModel() {

    private val _uiState = MutableStateFlow(CurrencyDetailsUiState(isLoading = true))
    val uiState = _uiState.asStateFlow()

    fun loadCurrencyDetails(code: String, table: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            val endDate = java.time.LocalDate.now(clock)
            val startDate = endDate.minusDays(14)

            runCatching {
                repository.getCurrencyDetails(code, table, startDate, endDate)
            }.onSuccess { details ->
                _uiState.value = CurrencyDetailsUiState(
                    details = CurrencyDetailsDisplay(
                    name = details.currencyName.toDisplayName(),
                    code = details.code,
                    currentRate = formatRate(details.currentRate),
                    history = details.history.map { historyItem ->
                        CurrencyHistoryUiItem(
                            date = historyItem.date.toString(),
                            rate = formatRate(historyItem.value),
                            isSignificantChange = historyItem.value.isMoreThanTenPercentAway(
                                details.currentRate,
                            )
                        )
                    }))
            }.onFailure {
                _uiState.value = CurrencyDetailsUiState(errorMessage = it.message)
            }
        }
    }

    private fun Double.isMoreThanTenPercentAway(
        currentValue: Double,
    ): Boolean {
        if (currentValue == 0.0) return false
        return abs(this - currentValue) / currentValue > 0.10
    }
}