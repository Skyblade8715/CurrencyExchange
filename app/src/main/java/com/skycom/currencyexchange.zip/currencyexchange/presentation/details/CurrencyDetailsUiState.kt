package com.skycom.currencyexchange.presentation.details

data class CurrencyDetailsUiState(
    val isLoading: Boolean = false,
    val details: CurrencyDetailsDisplay? = null,
    val errorMessage: String? = null,
)