package com.skycom.currencyexchange.presentation.list

import com.skycom.currencyexchange.domain.model.CurrencyListItem

data class CurrencyListUiState(
    val isLoading: Boolean = false,
    val currencies: List<CurrencyListUiItem> = emptyList(),
    val errorMessage: String? = null
)